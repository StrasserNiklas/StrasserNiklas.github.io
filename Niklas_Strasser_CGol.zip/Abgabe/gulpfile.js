const gulp = require('gulp');
const uncomment = require('gulp-uncomment');
const eslint = require('gulp-eslint');
const htmlhint = require('gulp-htmlhint');
const debug = require('gulp-debug');

function html() {
    return gulp.src('*.html')
        .pipe(debug({ title: 'html:' }))
        .pipe(htmlhint())
        .pipe(htmlhint.failOnError())
        .pipe(gulp.dest('./out'));
}

async function uncommentFunction() {
    return gulp.src('*.js')
        .pipe(uncomment({
            removeEmptyLines: true
        }))
        .pipe(gulp.dest('./out'));
}

async function copyLibs() {
    return gulp.src('*.css')
        .pipe(debug({ title: 'dep :' }))
        .pipe(gulp.dest('./out'));
}

async function esLint() {
    return gulp.src(['*.js'])
        .pipe(eslint())
        .pipe(eslint.format())
        .pipe(eslint.failAfterError());
}

exports.validate = html;
exports.copyLibs = copyLibs;
exports.eslint = esLint;
exports.js = uncommentFunction;
exports.default = gulp.parallel(html, esLint, uncommentFunction, copyLibs);
